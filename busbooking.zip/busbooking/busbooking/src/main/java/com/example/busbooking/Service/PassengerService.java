package com.example.busbooking.Service;

import com.example.busbooking.DTOs.PassengerDTO;
import com.example.busbooking.Entities.Passenger;
import com.example.busbooking.Repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PassengerService {

    @Autowired
    private PassengerRepository passengerRepository;

    public List<PassengerDTO> getAllPassengers() {
        return passengerRepository.findAll().stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    public PassengerDTO createPassenger(PassengerDTO passengerDTO) {
        Passenger passenger = convertToEntity(passengerDTO);
        return convertToDTO(passengerRepository.save(passenger));
    }

    private PassengerDTO convertToDTO(Passenger passenger) {
        PassengerDTO passengerDTO = new PassengerDTO();
        passengerDTO.setId(passenger.getId());
        passengerDTO.setName(passenger.getName());
        passengerDTO.setEmail(passenger.getEmail());
        return passengerDTO;
    }

    private Passenger convertToEntity(PassengerDTO passengerDTO) {
        Passenger passenger = new Passenger();
        passenger.setId(passengerDTO.getId());
        passenger.setName(passengerDTO.getName());
        passenger.setEmail(passengerDTO.getEmail());
        return passenger;
    }
}
