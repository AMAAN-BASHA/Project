package com.example.busbooking.Service;

import com.example.busbooking.DTOs.BookingDTO;
import com.example.busbooking.Entities.Booking;
import com.example.busbooking.Repository.BookingRepository;
import com.example.busbooking.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookingService {

    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;

    @Autowired
    public BookingService(BookingRepository bookingRepository, UserRepository userRepository) {
        this.bookingRepository = bookingRepository;
        this.userRepository = userRepository;
    }

    public List<BookingDTO> getAllBookings() {
        return bookingRepository.findAll().stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    public BookingDTO createBooking(BookingDTO bookingDTO) {
        Booking booking = convertToEntity(bookingDTO);
        return convertToDTO(bookingRepository.save(booking));
    }

    private BookingDTO convertToDTO(Booking booking) {
        BookingDTO bookingDTO = new BookingDTO();
        bookingDTO.setId(booking.getId());
        bookingDTO.setBusId(booking.getBusId());
        bookingDTO.setPassengerId(booking.getUser().getId());
        bookingDTO.setBookingDate(booking.getBookingDate());
        return bookingDTO;
    }

    private Booking convertToEntity(BookingDTO bookingDTO) {
        Booking booking = new Booking();
        booking.setId(bookingDTO.getId());
        booking.setBusId(bookingDTO.getBusId());
        booking.setUser(userRepository.findById(bookingDTO.getPassengerId()).orElse(null));
        booking.setBookingDate(bookingDTO.getBookingDate());
        return booking;
    }
}
