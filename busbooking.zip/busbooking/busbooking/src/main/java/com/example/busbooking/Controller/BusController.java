package com.example.busbooking.Controller;

import com.example.busbooking.DTOs.BusDTO;
import com.example.busbooking.Service.BusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/buses")
public class BusController {

    @Autowired
    private BusService busService;

    @GetMapping
    public List<BusDTO> getAllBuses() {
        return busService.getAllBuses();
    }

    @PostMapping
    public BusDTO createBus(@RequestBody BusDTO busDTO) {
        return busService.createBus(busDTO);
    }
}
