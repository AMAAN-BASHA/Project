package com.example.busbooking.Service;

import com.example.busbooking.DTOs.BusDTO;
import com.example.busbooking.Entities.Bus;
import com.example.busbooking.Repository.BusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BusService {

    @Autowired
    private BusRepository busRepository;

    public List<BusDTO> getAllBuses() {
        return busRepository.findAll().stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    public BusDTO createBus(BusDTO busDTO) {
        Bus bus = convertToEntity(busDTO);
        return convertToDTO(busRepository.save(bus));
    }

    private BusDTO convertToDTO(Bus bus) {
        BusDTO busDTO = new BusDTO();
        busDTO.setId(bus.getId());
        busDTO.setRoute(bus.getRoute());
        busDTO.setCapacity(bus.getCapacity());
        return busDTO;
    }

    private Bus convertToEntity(BusDTO busDTO) {
        Bus bus = new Bus();
        bus.setId(busDTO.getId());
        bus.setRoute(busDTO.getRoute());
        bus.setCapacity(busDTO.getCapacity());
        return bus;
    }
}
