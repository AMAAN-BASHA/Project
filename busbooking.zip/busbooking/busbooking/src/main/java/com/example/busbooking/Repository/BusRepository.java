package com.example.busbooking.Repository;

import com.example.busbooking.Entities.Bus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BusRepository extends JpaRepository<Bus, Long> {
}
