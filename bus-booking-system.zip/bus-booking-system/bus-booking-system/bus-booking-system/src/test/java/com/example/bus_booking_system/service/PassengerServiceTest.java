package com.example.bus_booking_system.service;

import com.example.bus_booking_system.Model.Passenger;
import com.example.bus_booking_system.Repository.PassengerRepository;
import com.example.bus_booking_system.Service.PassengerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class PassengerServiceTest {

    @Mock
    private PassengerRepository passengerRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private PassengerService passengerService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testRegisterPassenger() {
        Passenger passenger = new Passenger();
        passenger.setEmail("test@example.com");
        passenger.setPassword("password");

        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
        when(passengerRepository.save(any(Passenger.class))).thenReturn(passenger);

        Passenger registeredPassenger = passengerService.registerPassenger(passenger);

        assertNotNull(registeredPassenger);
        assertEquals("test@example.com", registeredPassenger.getEmail());
        assertEquals("encodedPassword", registeredPassenger.getPassword());
        verify(passengerRepository, times(1)).save(any(Passenger.class));
    }

    @Test
    void testGetPassengerById() {
        Passenger passenger = new Passenger();
        passenger.setId(1L);

        when(passengerRepository.findById(1L)).thenReturn(Optional.of(passenger));

        Passenger foundPassenger = passengerService.getPassengerById(1L);

        assertNotNull(foundPassenger);
        assertEquals(1L, foundPassenger.getId());
        verify(passengerRepository, times(1)).findById(1L);
    }

    @Test
    void testLoadUserByUsername() {
        Passenger passenger = new Passenger();
        passenger.setEmail("test@example.com");
        passenger.setPassword("password");

        when(passengerRepository.findByEmail("test@example.com")).thenReturn(passenger);

        assertDoesNotThrow(() -> {
            passengerService.loadUserByUsername("test@example.com");
        });
        verify(passengerRepository, times(1)).findByEmail("test@example.com");
    }
}
