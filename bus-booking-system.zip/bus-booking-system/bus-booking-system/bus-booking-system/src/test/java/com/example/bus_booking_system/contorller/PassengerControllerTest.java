package com.example.bus_booking_system.contorller;

import com.example.bus_booking_system.Controller.PassengerController;
import com.example.bus_booking_system.Model.Passenger;
import com.example.bus_booking_system.Service.PassengerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class PassengerControllerTest {

    private MockMvc mockMvc;

    @Mock
    private PassengerService passengerService;

    @InjectMocks
    private PassengerController passengerController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(passengerController).build();
    }

    @Test
    void testRegisterPassenger() throws Exception {
        Passenger passenger = new Passenger();
        passenger.setEmail("test@example.com");
        passenger.setPassword("password");

        when(passengerService.registerPassenger(any(Passenger.class))).thenReturn(passenger);

        mockMvc.perform(post("/api/passengers/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"test@example.com\",\"password\":\"password\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("test@example.com"));
    }

    @Test
    void testLoginPassenger() throws Exception {
        Passenger passenger = new Passenger();
        passenger.setEmail("test@example.com");
        passenger.setPassword("password");


        mockMvc.perform(post("/api/passengers/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"test@example.com\",\"password\":\"password\"}"))
                .andExpect(status().isOk())
                .andExpect(content().string("Login successful"));
    }
}
