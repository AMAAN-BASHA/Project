package com.example.bus_booking_system.Repository;

import com.example.bus_booking_system.Model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepository extends JpaRepository<Booking, Long> {
}
