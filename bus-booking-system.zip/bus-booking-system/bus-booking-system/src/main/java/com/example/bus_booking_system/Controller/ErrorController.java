package com.example.bus_booking_system.Controller;

import org.springframework.web.bind.annotation.RequestMapping;

public interface ErrorController extends org.springframework.boot.web.servlet.error.ErrorController {
    @RequestMapping("/error")
    String handleError();

    String getErrorPath();
}
