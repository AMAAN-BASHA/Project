package com.example.bus_booking_system.Service;

import com.example.bus_booking_system.Model.Bus;
import com.example.bus_booking_system.Repository.BusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BusService {
    @Autowired
    private BusRepository busRepository;

    public List<Bus> getAllBuses() {
        return busRepository.findAll();
    }

    public Bus getBusById(Long id) {
        return busRepository.findById(id).orElse(null);
    }

    public Bus createBus(Bus bus) {
        return busRepository.save(bus);
    }

    public Bus updateBus(Long id, Bus busDetails) {
        Bus bus = busRepository.findById(id).orElse(null);
        if (bus != null) {
            bus.setBusNumber(busDetails.getBusNumber());
            bus.setCapacity(busDetails.getCapacity());
            return busRepository.save(bus);
        }
        return null;
    }

    public void deleteBus(Long id) {
        busRepository.deleteById(id);
    }
}
