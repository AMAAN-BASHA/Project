package com.example.bus_booking_system.Service;


import com.example.bus_booking_system.Model.Passenger;
import com.example.bus_booking_system.Repository.PassengerRepository;
import com.example.bus_booking_system.SecurityConfiguration.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PassengerService implements UserDetailsService {

    @Autowired
    private PassengerRepository passengerRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtil jwtUtil;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Passenger passenger = passengerRepository.findByEmail(username);
        if (passenger == null) {
            throw new UsernameNotFoundException("User not found");
        }
        return new org.springframework.security.core.userdetails.User(passenger.getEmail(), passenger.getPassword(), new ArrayList<>());
    }

    public List<Passenger> getAllPassengers() {
        return passengerRepository.findAll();
    }

    public Passenger getPassengerById(Long id) {
        return passengerRepository.findById(id).orElse(null);
    }

    public Passenger registerPassenger(Passenger passenger) {
        passenger.setPassword(passwordEncoder.encode(passenger.getPassword()));
        return passengerRepository.save(passenger);
    }

    public String loginPassenger(Passenger passenger) throws Exception {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(passenger.getEmail(), passenger.getPassword())
            );
        } catch (Exception e) {
            throw new Exception("Invalid credentials");
        }

        final UserDetails userDetails = loadUserByUsername(passenger.getEmail());
        return jwtUtil.generateToken(userDetails);
    }

    public Passenger updatePassenger(Long id, Passenger passengerDetails) {
        Passenger passenger = passengerRepository.findById(id).orElse(null);
        if (passenger != null) {
            passenger.setEmail(passengerDetails.getEmail());
            passenger.setPassword(passwordEncoder.encode(passengerDetails.getPassword()));
            passenger.setName(passengerDetails.getName());
            return passengerRepository.save(passenger);
        }
        return null;
    }

    public void deletePassenger(Long id) {
        passengerRepository.deleteById(id);
    }

    public Passenger changePassword(Long id, String newPassword) {
        Passenger passenger = passengerRepository.findById(id).orElse(null);
        if (passenger != null) {
            passenger.setPassword(passwordEncoder.encode(newPassword));
            return passengerRepository.save(passenger);
        }
        return null;
    }
}
