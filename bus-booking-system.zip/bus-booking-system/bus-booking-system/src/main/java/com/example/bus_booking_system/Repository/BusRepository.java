package com.example.bus_booking_system.Repository;


import com.example.bus_booking_system.Model.Bus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BusRepository extends JpaRepository<Bus, Long> {
}
