package com.example.bus_booking_system.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CustomErrorController implements com.example.bus_booking_system.Controller.ErrorController {

    @RequestMapping("/error")
    @Override
    public String handleError() {
        // Return the custom error page
        return "error";
    }

    @Override
    public String getErrorPath() {
        return "/error";
    }
}
